export interface Transaction {
  id: string;
  type: 'send' | 'receive';
  amount: number;
  status: 'pending' | 'confirmed' | 'failed';
  timestamp: Date;
  from: string;
  to: string;
  txHash: string;
  confirmations?: number;
  fee?: number;
  blockHeight?: number;
}

export interface WalletData {
  address: string;
  balance: number;
  label: string;
  privateKey?: string;
  publicKey?: string;
  derivationPath?: string;
}

export interface NodeStatus {
  isRunning: boolean;
  blockHeight: number;
  connections: number;
  difficulty: number;
  mempool: number;
  uptime: number;
}

export interface TestScenario {
  id: string;
  name: string;
  description: string;
  steps: TestStep[];
  status: 'idle' | 'running' | 'completed' | 'failed';
  results?: TestResult[];
}

export interface TestStep {
  id: string;
  action: string;
  parameters: Record<string, any>;
  expectedResult: string;
}

export interface TestResult {
  stepId: string;
  success: boolean;
  actualResult: string;
  executionTime: number;
  error?: string;
}