import { useState, useEffect, useCallback } from 'react';
import { MidlService, MidlWalletInfo } from '../services/MidlService';
import { XverseService } from '../services/XverseService';

export const useWalletManager = (midlService: MidlService | null) => {
  const [wallets, setWallets] = useState<MidlWalletInfo[]>([]);
  const [xverseConnected, setXverseConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const xverseService = XverseService.getInstance();

  // Load wallets from Midl service
  const loadWallets = useCallback(async () => {
    if (!midlService) return;

    try {
      const walletList = midlService.getWallets();
      setWallets(walletList);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to load wallets');
    }
  }, [midlService]);

  // Connect Xverse wallet
  const connectXverse = useCallback(async () => {
    if (!midlService) {
      throw new Error('Midl service not initialized');
    }

    setIsLoading(true);
    try {
      const xverseWallets = await midlService.connectXverseWallet();
      setXverseConnected(true);
      
      // Reload all wallets to include Xverse wallets
      await loadWallets();
      
      setError(null);
      return xverseWallets;
    } catch (err: any) {
      setXverseConnected(false);
      setError(err.message || 'Failed to connect Xverse wallet');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [midlService, loadWallets]);

  // Disconnect Xverse wallet
  const disconnectXverse = useCallback(() => {
    xverseService.disconnect();
    setXverseConnected(false);
    
    // Remove Xverse wallets from the list
    setWallets(prev => prev.filter(w => w.type !== 'xverse'));
  }, [xverseService]);

  // Fund a wallet
  const fundWallet = useCallback(async (address: string, amount: number = 10) => {
    if (!midlService) {
      throw new Error('Midl service not initialized');
    }

    try {
      await midlService.fundWallet(address, amount);
      
      // Update wallet balance
      await midlService.updateWalletBalance(address);
      
      // Reload wallets to reflect new balance
      await loadWallets();
      
      return true;
    } catch (err: any) {
      throw new Error(err.message || 'Failed to fund wallet');
    }
  }, [midlService, loadWallets]);

  // Send transaction
  const sendTransaction = useCallback(async (from: string, to: string, amount: number) => {
    if (!midlService) {
      throw new Error('Midl service not initialized');
    }

    try {
      const result = await midlService.sendTransaction({
        from,
        to,
        amount,
        feeRate: 1
      });

      // Reload wallets to reflect new balances
      await loadWallets();
      
      return result;
    } catch (err: any) {
      throw new Error(err.message || 'Failed to send transaction');
    }
  }, [midlService, loadWallets]);

  // Create new wallet
  const createWallet = useCallback(async (walletName: string) => {
    if (!midlService) {
      throw new Error('Midl service not initialized');
    }

    try {
      const newWallet = await midlService.createWallet(walletName);
      await loadWallets();
      return newWallet;
    } catch (err: any) {
      throw new Error(err.message || 'Failed to create wallet');
    }
  }, [midlService, loadWallets]);

  // Update wallet balance
  const updateWalletBalance = useCallback(async (address: string) => {
    if (!midlService) return;

    try {
      const newBalance = await midlService.updateWalletBalance(address);
      
      // Update local state
      setWallets(prev => prev.map(w => 
        w.address === address ? { ...w, balance: newBalance } : w
      ));
      
      return newBalance;
    } catch (err: any) {
      console.error(`Failed to update balance for ${address}:`, err);
    }
  }, [midlService]);

  // Get wallet by address
  const getWallet = useCallback((address: string) => {
    return wallets.find(w => w.address === address);
  }, [wallets]);

  // Validate address
  const validateAddress = useCallback(async (address: string) => {
    if (!midlService) return false;
    
    try {
      return await midlService.validateAddress(address);
    } catch {
      return false;
    }
  }, [midlService]);

  // Load wallets when midlService is available
  useEffect(() => {
    if (midlService) {
      loadWallets();
    }
  }, [midlService, loadWallets]);

  // Set up Xverse account change listener
  useEffect(() => {
    if (xverseConnected) {
      xverseService.onAccountsChanged((accounts) => {
        if (accounts.length === 0) {
          setXverseConnected(false);
          setWallets(prev => prev.filter(w => w.type !== 'xverse'));
        } else {
          loadWallets();
        }
      });
    }

    return () => {
      xverseService.removeAllListeners();
    };
  }, [xverseConnected, xverseService, loadWallets]);

  return {
    wallets,
    xverseConnected,
    isLoading,
    error,
    connectXverse,
    disconnectXverse,
    fundWallet,
    sendTransaction,
    createWallet,
    updateWalletBalance,
    getWallet,
    validateAddress,
    loadWallets
  };
};