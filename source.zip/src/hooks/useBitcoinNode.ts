import { useState, useEffect, useCallback } from 'react';
import { BitcoinService } from '../services/BitcoinService';
import { MidlService } from '../services/MidlService';
import { NodeStatus } from '../types';

export const useBitcoinNode = () => {
  const [nodeStatus, setNodeStatus] = useState<NodeStatus>({
    isRunning: false,
    blockHeight: 0,
    connections: 0,
    difficulty: 1.0,
    mempool: 0,
    uptime: 0
  });
  
  const [bitcoinService, setBitcoinService] = useState<BitcoinService | null>(null);
  const [midlService, setMidlService] = useState<MidlService | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize Bitcoin service
  const initializeBitcoinService = useCallback(() => {
    const config = {
      host: 'localhost',
      port: 18443, // Default regtest port
      username: 'bitcoin',
      password: 'bitcoin',
      network: 'regtest' as const
    };

    const service = new BitcoinService(config);
    setBitcoinService(service);
    
    const midl = new MidlService(service);
    setMidlService(midl);
    
    return { bitcoinService: service, midlService: midl };
  }, []);

  // Check node status
  const checkNodeStatus = useCallback(async (service: BitcoinService) => {
    try {
      const isRunning = await service.isNodeRunning();
      
      if (isRunning) {
        const [blockchainInfo, networkInfo] = await Promise.all([
          service.getBlockchainInfo(),
          service.getNetworkInfo()
        ]);

        const connectionCount = await service.getConnectionCount();
        const mempoolInfo = await service.getMempoolInfo();

        setNodeStatus({
          isRunning: true,
          blockHeight: blockchainInfo.blocks,
          connections: connectionCount,
          difficulty: blockchainInfo.difficulty,
          mempool: mempoolInfo.size,
          uptime: Date.now() // Simplified uptime
        });
        
        setError(null);
      } else {
        setNodeStatus(prev => ({
          ...prev,
          isRunning: false,
          connections: 0,
          mempool: 0
        }));
        
        setError('Bitcoin regtest node is not running. Please start bitcoind with -regtest flag.');
      }
    } catch (err: any) {
      setNodeStatus(prev => ({
        ...prev,
        isRunning: false,
        connections: 0,
        mempool: 0
      }));
      
      setError(err.message || 'Failed to connect to Bitcoin node');
    }
  }, []);

  // Start monitoring node
  const startNodeMonitoring = useCallback(async () => {
    setIsLoading(true);
    
    try {
      const { bitcoinService: service, midlService: midl } = initializeBitcoinService();
      
      // Initial status check
      await checkNodeStatus(service);
      
      // Initialize Midl service if node is running
      if (nodeStatus.isRunning) {
        try {
          await midl.initialize();
        } catch (midlError) {
          console.warn('Midl service initialization failed:', midlError);
        }
      }
      
    } catch (err: any) {
      setError(err.message || 'Failed to initialize Bitcoin services');
    } finally {
      setIsLoading(false);
    }
  }, [initializeBitcoinService, checkNodeStatus, nodeStatus.isRunning]);

  // Stop monitoring
  const stopNodeMonitoring = useCallback(() => {
    setNodeStatus({
      isRunning: false,
      blockHeight: 0,
      connections: 0,
      difficulty: 1.0,
      mempool: 0,
      uptime: 0
    });
    setError(null);
  }, []);

  // Mine blocks
  const mineBlocks = useCallback(async (count: number = 1) => {
    if (!midlService || !nodeStatus.isRunning) {
      throw new Error('Node is not running or Midl service not initialized');
    }

    try {
      const blockHashes = await midlService.mineBlocks(count);
      
      // Update node status after mining
      if (bitcoinService) {
        await checkNodeStatus(bitcoinService);
      }
      
      return blockHashes;
    } catch (err: any) {
      throw new Error(`Failed to mine blocks: ${err.message}`);
    }
  }, [midlService, nodeStatus.isRunning, bitcoinService, checkNodeStatus]);

  // Get blockchain info
  const getBlockchainInfo = useCallback(async () => {
    if (!midlService) {
      throw new Error('Midl service not initialized');
    }
    
    return await midlService.getBlockchainInfo();
  }, [midlService]);

  // Initialize on mount
  useEffect(() => {
    startNodeMonitoring();
  }, []);

  // Set up periodic status updates
  useEffect(() => {
    if (!bitcoinService || !nodeStatus.isRunning) return;

    const interval = setInterval(async () => {
      try {
        await checkNodeStatus(bitcoinService);
      } catch (err) {
        console.error('Status update failed:', err);
      }
    }, 10000); // Update every 10 seconds

    return () => clearInterval(interval);
  }, [bitcoinService, nodeStatus.isRunning, checkNodeStatus]);

  return {
    nodeStatus,
    bitcoinService,
    midlService,
    isLoading,
    error,
    startNodeMonitoring,
    stopNodeMonitoring,
    mineBlocks,
    getBlockchainInfo
  };
};