// Xverse Wallet Integration Service
export interface XverseAccount {
  address: string;
  publicKey: string;
  purpose: string;
  addressType: 'p2wpkh' | 'p2tr' | 'p2sh';
}

export interface XverseSignTransactionOptions {
  psbtBase64: string;
  broadcast?: boolean;
  inputsToSign?: Array<{
    address: string;
    signingIndexes: number[];
  }>;
}

export interface XverseSignTransactionResponse {
  psbtBase64: string;
  txid?: string;
}

export interface XverseSignMessageOptions {
  address: string;
  message: string;
}

export interface XverseSignMessageResponse {
  signature: string;
}

export class XverseService {
  private static instance: XverseService;
  private isConnected: boolean = false;
  private accounts: XverseAccount[] = [];

  private constructor() {}

  static getInstance(): XverseService {
    if (!XverseService.instance) {
      XverseService.instance = new XverseService();
    }
    return XverseService.instance;
  }

  // Check if Xverse is installed
  isXverseInstalled(): boolean {
    return typeof window !== 'undefined' && 'BitcoinProvider' in window;
  }

  // Connect to Xverse wallet
  async connect(): Promise<XverseAccount[]> {
    if (!this.isXverseInstalled()) {
      throw new Error('Xverse wallet is not installed. Please install the Xverse browser extension.');
    }

    try {
      const response = await (window as any).BitcoinProvider.request('getAccounts', {
        purposes: ['ordinals', 'payment'],
        message: 'BTC-TestFlow would like to connect to your wallet for testing Bitcoin transactions.',
      });

      if (response.status === 'success') {
        this.accounts = response.result.map((account: any) => ({
          address: account.address,
          publicKey: account.publicKey,
          purpose: account.purpose,
          addressType: account.addressType
        }));
        this.isConnected = true;
        return this.accounts;
      } else {
        throw new Error(response.error?.message || 'Failed to connect to Xverse wallet');
      }
    } catch (error: any) {
      this.isConnected = false;
      throw new Error(`Xverse connection failed: ${error.message}`);
    }
  }

  // Disconnect from Xverse wallet
  disconnect(): void {
    this.isConnected = false;
    this.accounts = [];
  }

  // Get connected accounts
  getAccounts(): XverseAccount[] {
    return this.accounts;
  }

  // Check connection status
  getConnectionStatus(): boolean {
    return this.isConnected;
  }

  // Sign and broadcast transaction
  async signTransaction(options: XverseSignTransactionOptions): Promise<XverseSignTransactionResponse> {
    if (!this.isConnected) {
      throw new Error('Wallet not connected. Please connect your Xverse wallet first.');
    }

    try {
      const response = await (window as any).BitcoinProvider.request('signTransaction', {
        psbtBase64: options.psbtBase64,
        broadcast: options.broadcast || false,
        inputsToSign: options.inputsToSign || []
      });

      if (response.status === 'success') {
        return {
          psbtBase64: response.result.psbtBase64,
          txid: response.result.txid
        };
      } else {
        throw new Error(response.error?.message || 'Transaction signing failed');
      }
    } catch (error: any) {
      throw new Error(`Transaction signing failed: ${error.message}`);
    }
  }

  // Sign message
  async signMessage(options: XverseSignMessageOptions): Promise<XverseSignMessageResponse> {
    if (!this.isConnected) {
      throw new Error('Wallet not connected. Please connect your Xverse wallet first.');
    }

    try {
      const response = await (window as any).BitcoinProvider.request('signMessage', {
        address: options.address,
        message: options.message
      });

      if (response.status === 'success') {
        return {
          signature: response.result.signature
        };
      } else {
        throw new Error(response.error?.message || 'Message signing failed');
      }
    } catch (error: any) {
      throw new Error(`Message signing failed: ${error.message}`);
    }
  }

  // Send Bitcoin (creates and broadcasts transaction)
  async sendBitcoin(recipientAddress: string, amount: number, feeRate?: number): Promise<string> {
    if (!this.isConnected) {
      throw new Error('Wallet not connected. Please connect your Xverse wallet first.');
    }

    try {
      const response = await (window as any).BitcoinProvider.request('sendTransfer', {
        recipients: [
          {
            address: recipientAddress,
            amount: Math.floor(amount * 100000000) // Convert to satoshis
          }
        ],
        feeRate: feeRate || 1 // Default fee rate
      });

      if (response.status === 'success') {
        return response.result.txid;
      } else {
        throw new Error(response.error?.message || 'Transaction failed');
      }
    } catch (error: any) {
      throw new Error(`Send transaction failed: ${error.message}`);
    }
  }

  // Get wallet balance (if supported)
  async getBalance(): Promise<{ confirmed: number; unconfirmed: number; total: number }> {
    if (!this.isConnected) {
      throw new Error('Wallet not connected. Please connect your Xverse wallet first.');
    }

    try {
      const response = await (window as any).BitcoinProvider.request('getBalance');

      if (response.status === 'success') {
        return {
          confirmed: response.result.confirmed / 100000000, // Convert from satoshis
          unconfirmed: response.result.unconfirmed / 100000000,
          total: response.result.total / 100000000
        };
      } else {
        throw new Error(response.error?.message || 'Failed to get balance');
      }
    } catch (error: any) {
      // If balance API is not available, return zeros
      console.warn('Balance API not available:', error.message);
      return { confirmed: 0, unconfirmed: 0, total: 0 };
    }
  }

  // Listen for account changes
  onAccountsChanged(callback: (accounts: XverseAccount[]) => void): void {
    if (this.isXverseInstalled()) {
      (window as any).BitcoinProvider.on('accountsChanged', (accounts: any[]) => {
        this.accounts = accounts.map((account: any) => ({
          address: account.address,
          publicKey: account.publicKey,
          purpose: account.purpose,
          addressType: account.addressType
        }));
        callback(this.accounts);
      });
    }
  }

  // Remove event listeners
  removeAllListeners(): void {
    if (this.isXverseInstalled()) {
      (window as any).BitcoinProvider.removeAllListeners();
    }
  }
}