// Midl.js Integration Service for Bitcoin Operations
import { BitcoinService } from './BitcoinService';
import { XverseService } from './XverseService';

export interface MidlTransactionRequest {
  from: string;
  to: string;
  amount: number;
  feeRate?: number;
  walletName?: string;
}

export interface MidlTransactionResponse {
  txid: string;
  status: 'pending' | 'confirmed' | 'failed';
  confirmations: number;
  fee: number;
  blockHeight?: number;
}

export interface MidlWalletInfo {
  address: string;
  balance: number;
  label: string;
  type: 'regtest' | 'xverse';
  derivationPath?: string;
}

export class MidlService {
  private bitcoinService: BitcoinService;
  private xverseService: XverseService;
  private wallets: Map<string, MidlWalletInfo> = new Map();

  constructor(bitcoinService: BitcoinService) {
    this.bitcoinService = bitcoinService;
    this.xverseService = XverseService.getInstance();
  }

  // Initialize the service
  async initialize(): Promise<void> {
    try {
      // Check if Bitcoin node is running
      const isRunning = await this.bitcoinService.isNodeRunning();
      if (!isRunning) {
        throw new Error('Bitcoin regtest node is not running');
      }

      // Load existing wallets
      await this.loadRegtestWallets();
      
      console.log('Midl service initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Midl service:', error);
      throw error;
    }
  }

  // Load regtest wallets
  private async loadRegtestWallets(): Promise<void> {
    const defaultWallets = ['main_wallet', 'test_wallet_1', 'test_wallet_2'];
    
    for (const walletName of defaultWallets) {
      try {
        // Try to load existing wallet or create new one
        await this.bitcoinService.loadWallet(walletName);
        
        // Get wallet info
        const balance = await this.bitcoinService.getBalance(walletName);
        const address = await this.bitcoinService.getNewAddress(walletName);
        
        this.wallets.set(address, {
          address,
          balance,
          label: walletName.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
          type: 'regtest',
          derivationPath: `m/84'/1'/0'/0/${this.wallets.size}`
        });
      } catch (error) {
        // If wallet doesn't exist, create it
        try {
          await this.bitcoinService.createWallet(walletName);
          const address = await this.bitcoinService.getNewAddress(walletName);
          
          this.wallets.set(address, {
            address,
            balance: 0,
            label: walletName.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
            type: 'regtest',
            derivationPath: `m/84'/1'/0'/0/${this.wallets.size}`
          });
        } catch (createError) {
          console.error(`Failed to create wallet ${walletName}:`, createError);
        }
      }
    }
  }

  // Connect Xverse wallet
  async connectXverseWallet(): Promise<MidlWalletInfo[]> {
    try {
      const accounts = await this.xverseService.connect();
      const xverseWallets: MidlWalletInfo[] = [];

      for (const account of accounts) {
        try {
          const balance = await this.xverseService.getBalance();
          const walletInfo: MidlWalletInfo = {
            address: account.address,
            balance: balance.total,
            label: `Xverse ${account.purpose}`,
            type: 'xverse'
          };
          
          this.wallets.set(account.address, walletInfo);
          xverseWallets.push(walletInfo);
        } catch (balanceError) {
          // If balance fetch fails, still add wallet with 0 balance
          const walletInfo: MidlWalletInfo = {
            address: account.address,
            balance: 0,
            label: `Xverse ${account.purpose}`,
            type: 'xverse'
          };
          
          this.wallets.set(account.address, walletInfo);
          xverseWallets.push(walletInfo);
        }
      }

      return xverseWallets;
    } catch (error) {
      console.error('Failed to connect Xverse wallet:', error);
      throw error;
    }
  }

  // Get all wallets
  getWallets(): MidlWalletInfo[] {
    return Array.from(this.wallets.values());
  }

  // Get wallet by address
  getWallet(address: string): MidlWalletInfo | undefined {
    return this.wallets.get(address);
  }

  // Update wallet balance
  async updateWalletBalance(address: string): Promise<number> {
    const wallet = this.wallets.get(address);
    if (!wallet) {
      throw new Error(`Wallet not found: ${address}`);
    }

    try {
      let balance = 0;
      
      if (wallet.type === 'regtest') {
        // Find wallet name for this address
        const walletName = wallet.label.toLowerCase().replace(' ', '_');
        balance = await this.bitcoinService.getBalance(walletName);
      } else if (wallet.type === 'xverse') {
        const xverseBalance = await this.xverseService.getBalance();
        balance = xverseBalance.total;
      }

      // Update wallet balance
      wallet.balance = balance;
      this.wallets.set(address, wallet);
      
      return balance;
    } catch (error) {
      console.error(`Failed to update balance for ${address}:`, error);
      return wallet.balance; // Return cached balance
    }
  }

  // Fund a regtest wallet
  async fundWallet(address: string, amount: number): Promise<string> {
    const wallet = this.wallets.get(address);
    if (!wallet) {
      throw new Error(`Wallet not found: ${address}`);
    }

    if (wallet.type !== 'regtest') {
      throw new Error('Can only fund regtest wallets');
    }

    try {
      // Generate blocks to the wallet address to fund it
      const blocks = Math.ceil(amount / 50); // Each block gives 50 BTC reward
      const blockHashes = await this.bitcoinService.generateToAddress(address, blocks);
      
      // Update wallet balance
      await this.updateWalletBalance(address);
      
      return blockHashes[0]; // Return first block hash
    } catch (error) {
      console.error(`Failed to fund wallet ${address}:`, error);
      throw error;
    }
  }

  // Send transaction
  async sendTransaction(request: MidlTransactionRequest): Promise<MidlTransactionResponse> {
    const fromWallet = this.wallets.get(request.from);
    if (!fromWallet) {
      throw new Error(`Source wallet not found: ${request.from}`);
    }

    try {
      let txid: string;
      let fee = 0.00001; // Default fee

      if (fromWallet.type === 'regtest') {
        // Use Bitcoin Core RPC for regtest transactions
        const walletName = fromWallet.label.toLowerCase().replace(' ', '_');
        txid = await this.bitcoinService.sendToAddress(walletName, request.to, request.amount);
        fee = request.feeRate ? request.feeRate * 0.00001 : 0.00001;
      } else if (fromWallet.type === 'xverse') {
        // Use Xverse for external transactions
        txid = await this.xverseService.sendBitcoin(request.to, request.amount, request.feeRate);
        fee = request.feeRate ? request.feeRate * 0.00001 : 0.00001;
      } else {
        throw new Error('Unsupported wallet type');
      }

      // Update wallet balances
      await this.updateWalletBalance(request.from);
      if (this.wallets.has(request.to)) {
        await this.updateWalletBalance(request.to);
      }

      // Get current block height
      const blockHeight = await this.bitcoinService.getBlockCount();

      return {
        txid,
        status: 'pending',
        confirmations: 0,
        fee,
        blockHeight
      };
    } catch (error) {
      console.error('Transaction failed:', error);
      throw error;
    }
  }

  // Get transaction details
  async getTransaction(txid: string, walletAddress?: string): Promise<MidlTransactionResponse | null> {
    try {
      if (walletAddress) {
        const wallet = this.wallets.get(walletAddress);
        if (wallet && wallet.type === 'regtest') {
          const walletName = wallet.label.toLowerCase().replace(' ', '_');
          const tx = await this.bitcoinService.getTransaction(walletName, txid);
          
          return {
            txid: tx.txid,
            status: tx.confirmations >= 6 ? 'confirmed' : 'pending',
            confirmations: tx.confirmations || 0,
            fee: Math.abs(tx.fee || 0),
            blockHeight: tx.blockheight
          };
        }
      }

      // Try to get raw transaction
      const rawTx = await this.bitcoinService.getRawTransaction(txid);
      const blockHeight = await this.bitcoinService.getBlockCount();
      
      return {
        txid: rawTx.txid,
        status: rawTx.confirmations && rawTx.confirmations >= 6 ? 'confirmed' : 'pending',
        confirmations: rawTx.confirmations || 0,
        fee: 0.00001, // Estimate fee
        blockHeight: blockHeight
      };
    } catch (error) {
      console.error(`Failed to get transaction ${txid}:`, error);
      return null;
    }
  }

  // Mine blocks (regtest only)
  async mineBlocks(count: number): Promise<string[]> {
    try {
      return await this.bitcoinService.generateBlocks(count);
    } catch (error) {
      console.error('Failed to mine blocks:', error);
      throw error;
    }
  }

  // Get blockchain info
  async getBlockchainInfo(): Promise<any> {
    try {
      return await this.bitcoinService.getBlockchainInfo();
    } catch (error) {
      console.error('Failed to get blockchain info:', error);
      throw error;
    }
  }

  // Get network info
  async getNetworkInfo(): Promise<any> {
    try {
      const networkInfo = await this.bitcoinService.getNetworkInfo();
      const connectionCount = await this.bitcoinService.getConnectionCount();
      const mempoolInfo = await this.bitcoinService.getMempoolInfo();
      
      return {
        ...networkInfo,
        connections: connectionCount,
        mempool: mempoolInfo.size
      };
    } catch (error) {
      console.error('Failed to get network info:', error);
      throw error;
    }
  }

  // Validate Bitcoin address
  async validateAddress(address: string): Promise<boolean> {
    try {
      const result = await this.bitcoinService.validateAddress(address);
      return result.isvalid;
    } catch (error) {
      console.error(`Failed to validate address ${address}:`, error);
      return false;
    }
  }

  // Create new regtest wallet
  async createWallet(walletName: string): Promise<MidlWalletInfo> {
    try {
      await this.bitcoinService.createWallet(walletName);
      const address = await this.bitcoinService.getNewAddress(walletName);
      
      const walletInfo: MidlWalletInfo = {
        address,
        balance: 0,
        label: walletName.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
        type: 'regtest',
        derivationPath: `m/84'/1'/0'/0/${this.wallets.size}`
      };
      
      this.wallets.set(address, walletInfo);
      return walletInfo;
    } catch (error) {
      console.error(`Failed to create wallet ${walletName}:`, error);
      throw error;
    }
  }
}