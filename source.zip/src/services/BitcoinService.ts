import axios from 'axios';

export interface BitcoinRPCConfig {
  host: string;
  port: number;
  username: string;
  password: string;
  network: 'regtest' | 'testnet' | 'mainnet';
}

export interface UTXOInfo {
  txid: string;
  vout: number;
  amount: number;
  confirmations: number;
  spendable: boolean;
}

export interface BlockchainInfo {
  chain: string;
  blocks: number;
  headers: number;
  bestblockhash: string;
  difficulty: number;
  mediantime: number;
  verificationprogress: number;
  initialblockdownload: boolean;
  chainwork: string;
  size_on_disk: number;
  pruned: boolean;
}

export interface WalletInfo {
  walletname: string;
  walletversion: number;
  format: string;
  balance: number;
  unconfirmed_balance: number;
  immature_balance: number;
  txcount: number;
  keypoololdest: number;
  keypoolsize: number;
  hdseedid?: string;
  private_keys_enabled: boolean;
  avoid_reuse: boolean;
  scanning: boolean;
}

export interface TransactionInfo {
  txid: string;
  hash: string;
  version: number;
  size: number;
  vsize: number;
  weight: number;
  locktime: number;
  vin: Array<{
    txid: string;
    vout: number;
    scriptSig: {
      asm: string;
      hex: string;
    };
    sequence: number;
  }>;
  vout: Array<{
    value: number;
    n: number;
    scriptPubKey: {
      asm: string;
      hex: string;
      reqSigs?: number;
      type: string;
      addresses?: string[];
    };
  }>;
  hex: string;
  blockhash?: string;
  confirmations?: number;
  time?: number;
  blocktime?: number;
}

export class BitcoinService {
  private config: BitcoinRPCConfig;
  private baseUrl: string;

  constructor(config: BitcoinRPCConfig) {
    this.config = config;
    this.baseUrl = `http://${config.host}:${config.port}`;
  }

  private async rpcCall(method: string, params: any[] = []): Promise<any> {
    try {
      const response = await axios.post(this.baseUrl, {
        jsonrpc: '2.0',
        id: Date.now(),
        method,
        params
      }, {
        auth: {
          username: this.config.username,
          password: this.config.password
        },
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });

      if (response.data.error) {
        throw new Error(`Bitcoin RPC Error: ${response.data.error.message}`);
      }

      return response.data.result;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        if (error.code === 'ECONNREFUSED') {
          throw new Error('Bitcoin node is not running. Please start bitcoind with -regtest flag.');
        }
        throw new Error(`Network error: ${error.message}`);
      }
      throw error;
    }
  }

  // Node Management
  async getBlockchainInfo(): Promise<BlockchainInfo> {
    return await this.rpcCall('getblockchaininfo');
  }

  async getNetworkInfo(): Promise<any> {
    return await this.rpcCall('getnetworkinfo');
  }

  async getMempoolInfo(): Promise<any> {
    return await this.rpcCall('getmempoolinfo');
  }

  async isNodeRunning(): Promise<boolean> {
    try {
      await this.getBlockchainInfo();
      return true;
    } catch {
      return false;
    }
  }

  // Wallet Management
  async createWallet(walletName: string): Promise<any> {
    try {
      return await this.rpcCall('createwallet', [walletName, false, false, '', false, true]);
    } catch (error: any) {
      if (error.message.includes('already exists')) {
        return { name: walletName, warning: 'Wallet already exists' };
      }
      throw error;
    }
  }

  async loadWallet(walletName: string): Promise<any> {
    try {
      return await this.rpcCall('loadwallet', [walletName]);
    } catch (error: any) {
      if (error.message.includes('already loaded')) {
        return { name: walletName, warning: 'Wallet already loaded' };
      }
      throw error;
    }
  }

  async getWalletInfo(walletName?: string): Promise<WalletInfo> {
    const endpoint = walletName ? `/wallet/${walletName}` : '';
    const originalUrl = this.baseUrl;
    this.baseUrl = `${originalUrl}${endpoint}`;
    
    try {
      const result = await this.rpcCall('getwalletinfo');
      this.baseUrl = originalUrl;
      return result;
    } catch (error) {
      this.baseUrl = originalUrl;
      throw error;
    }
  }

  async getNewAddress(walletName: string, label?: string): Promise<string> {
    const originalUrl = this.baseUrl;
    this.baseUrl = `${originalUrl}/wallet/${walletName}`;
    
    try {
      const result = await this.rpcCall('getnewaddress', label ? [label] : []);
      this.baseUrl = originalUrl;
      return result;
    } catch (error) {
      this.baseUrl = originalUrl;
      throw error;
    }
  }

  async getBalance(walletName: string): Promise<number> {
    const originalUrl = this.baseUrl;
    this.baseUrl = `${originalUrl}/wallet/${walletName}`;
    
    try {
      const result = await this.rpcCall('getbalance');
      this.baseUrl = originalUrl;
      return result;
    } catch (error) {
      this.baseUrl = originalUrl;
      throw error;
    }
  }

  async listUnspent(walletName: string, minconf: number = 0): Promise<UTXOInfo[]> {
    const originalUrl = this.baseUrl;
    this.baseUrl = `${originalUrl}/wallet/${walletName}`;
    
    try {
      const result = await this.rpcCall('listunspent', [minconf]);
      this.baseUrl = originalUrl;
      return result;
    } catch (error) {
      this.baseUrl = originalUrl;
      throw error;
    }
  }

  // Transaction Management
  async sendToAddress(walletName: string, address: string, amount: number): Promise<string> {
    const originalUrl = this.baseUrl;
    this.baseUrl = `${originalUrl}/wallet/${walletName}`;
    
    try {
      const result = await this.rpcCall('sendtoaddress', [address, amount]);
      this.baseUrl = originalUrl;
      return result;
    } catch (error) {
      this.baseUrl = originalUrl;
      throw error;
    }
  }

  async getTransaction(walletName: string, txid: string): Promise<any> {
    const originalUrl = this.baseUrl;
    this.baseUrl = `${originalUrl}/wallet/${walletName}`;
    
    try {
      const result = await this.rpcCall('gettransaction', [txid]);
      this.baseUrl = originalUrl;
      return result;
    } catch (error) {
      this.baseUrl = originalUrl;
      throw error;
    }
  }

  async getRawTransaction(txid: string, verbose: boolean = true): Promise<TransactionInfo> {
    return await this.rpcCall('getrawtransaction', [txid, verbose]);
  }

  async listTransactions(walletName: string, count: number = 10): Promise<any[]> {
    const originalUrl = this.baseUrl;
    this.baseUrl = `${originalUrl}/wallet/${walletName}`;
    
    try {
      const result = await this.rpcCall('listtransactions', ['*', count]);
      this.baseUrl = originalUrl;
      return result;
    } catch (error) {
      this.baseUrl = originalUrl;
      throw error;
    }
  }

  // Mining (Regtest only)
  async generateToAddress(address: string, blocks: number): Promise<string[]> {
    if (this.config.network !== 'regtest') {
      throw new Error('Mining is only available in regtest mode');
    }
    return await this.rpcCall('generatetoaddress', [blocks, address]);
  }

  async generateBlocks(blocks: number): Promise<string[]> {
    if (this.config.network !== 'regtest') {
      throw new Error('Mining is only available in regtest mode');
    }
    
    // Get a mining address first
    try {
      const address = await this.getNewAddress('mining_wallet');
      return await this.generateToAddress(address, blocks);
    } catch {
      // If no wallet exists, create one for mining
      await this.createWallet('mining_wallet');
      const address = await this.getNewAddress('mining_wallet');
      return await this.generateToAddress(address, blocks);
    }
  }

  // Utility Methods
  async validateAddress(address: string): Promise<any> {
    return await this.rpcCall('validateaddress', [address]);
  }

  async estimateSmartFee(blocks: number): Promise<any> {
    return await this.rpcCall('estimatesmartfee', [blocks]);
  }

  async getBlockCount(): Promise<number> {
    return await this.rpcCall('getblockcount');
  }

  async getConnectionCount(): Promise<number> {
    return await this.rpcCall('getconnectioncount');
  }

  async getMiningInfo(): Promise<any> {
    return await this.rpcCall('getmininginfo');
  }
}