import React from 'react';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Copy,
  ExternalLink
} from 'lucide-react';
import { Transaction } from '../types';

interface TransactionCardProps {
  transaction: Transaction;
  onCopyHash: (hash: string) => void;
}

export const TransactionCard: React.FC<TransactionCardProps> = ({ 
  transaction, 
  onCopyHash 
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'text-green-400 bg-green-400/10';
      case 'pending': return 'text-yellow-400 bg-yellow-400/10';
      case 'failed': return 'text-red-400 bg-red-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed': return <CheckCircle className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'failed': return <AlertCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (minutes < 1440) return `${Math.floor(minutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="bg-slate-700 p-4 rounded-lg hover:bg-slate-600/50 transition-all duration-200 group">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${
            transaction.type === 'send' 
              ? 'bg-red-500/20 text-red-400' 
              : 'bg-green-500/20 text-green-400'
          }`}>
            {transaction.type === 'send' ? 
              <ArrowUpRight className="h-4 w-4" /> : 
              <ArrowDownLeft className="h-4 w-4" />
            }
          </div>
          <div>
            <p className="font-semibold text-white capitalize">{transaction.type}</p>
            <p className="text-sm text-slate-400">
              {transaction.from.length > 20 ? 
                `${transaction.from.slice(0, 10)}...${transaction.from.slice(-6)}` : 
                transaction.from
              } → {transaction.to.length > 20 ? 
                `${transaction.to.slice(0, 10)}...${transaction.to.slice(-6)}` : 
                transaction.to
              }
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold text-white">
            {transaction.type === 'send' ? '-' : '+'}{transaction.amount.toFixed(8)} BTC
          </p>
          <div className={`flex items-center space-x-1 justify-end px-2 py-1 rounded-full text-xs ${getStatusColor(transaction.status)}`}>
            {getStatusIcon(transaction.status)}
            <span className="capitalize font-medium">{transaction.status}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-between pt-3 border-t border-slate-600">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => onCopyHash(transaction.txHash)}
            className="flex items-center space-x-1 text-xs text-slate-400 hover:text-orange-400 transition-colors"
          >
            <Copy className="h-3 w-3" />
            <span className="font-mono">{transaction.txHash}</span>
          </button>
          <button className="flex items-center space-x-1 text-xs text-slate-400 hover:text-orange-400 transition-colors">
            <ExternalLink className="h-3 w-3" />
            <span>Explorer</span>
          </button>
        </div>
        <span className="text-xs text-slate-400">{formatTime(transaction.timestamp)}</span>
      </div>
      
      {transaction.confirmations !== undefined && (
        <div className="mt-2 pt-2 border-t border-slate-600">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Confirmations</span>
            <span className={`font-medium ${
              transaction.confirmations >= 6 ? 'text-green-400' : 'text-yellow-400'
            }`}>
              {transaction.confirmations}/6
            </span>
          </div>
          <div className="mt-1 w-full bg-slate-600 rounded-full h-1">
            <div 
              className={`h-1 rounded-full transition-all duration-500 ${
                transaction.confirmations >= 6 ? 'bg-green-400' : 'bg-yellow-400'
              }`}
              style={{ width: `${Math.min((transaction.confirmations / 6) * 100, 100)}%` }}
            ></div>
          </div>
        </div>
      )}
    </div>
  );
};