import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Lightbulb,
  Target,
  Zap,
  BarChart3,
  Activity,
  Cpu
} from 'lucide-react';
import { Transaction, TestScenario } from '../types';
import { MidlWalletInfo } from '../services/MidlService';

interface AIInsightsProps {
  transactions: Transaction[];
  wallets: MidlWalletInfo[];
  testScenarios: TestScenario[];
}

interface AIInsight {
  id: string;
  type: 'optimization' | 'warning' | 'recommendation' | 'prediction';
  title: string;
  description: string;
  confidence: number;
  impact: 'high' | 'medium' | 'low';
  actionable: boolean;
}

export const AIInsights: React.FC<AIInsightsProps> = ({
  transactions,
  wallets,
  testScenarios
}) => {
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // AI Analysis Engine (Simulated)
  const generateInsights = () => {
    setIsAnalyzing(true);
    
    setTimeout(() => {
      const newInsights: AIInsight[] = [];
      
      // Transaction Pattern Analysis
      const successRate = transactions.length > 0 
        ? (transactions.filter(tx => tx.status === 'confirmed').length / transactions.length) * 100 
        : 0;
      
      if (successRate < 80 && transactions.length > 5) {
        newInsights.push({
          id: '1',
          type: 'warning',
          title: 'Low Transaction Success Rate Detected',
          description: `Your transaction success rate is ${successRate.toFixed(1)}%. Consider optimizing fee rates or checking network conditions.`,
          confidence: 85,
          impact: 'high',
          actionable: true
        });
      }
      
      // Wallet Balance Optimization
      const totalBalance = wallets.reduce((sum, w) => sum + w.balance, 0);
      const activeWallets = wallets.filter(w => w.balance > 0).length;
      
      if (activeWallets < wallets.length && totalBalance > 0) {
        newInsights.push({
          id: '2',
          type: 'optimization',
          title: 'Wallet Balance Distribution Opportunity',
          description: `${wallets.length - activeWallets} wallets have zero balance. Consider redistributing funds for better test coverage.`,
          confidence: 92,
          impact: 'medium',
          actionable: true
        });
      }
      
      // Test Scenario Performance
      const completedScenarios = testScenarios.filter(s => s.status === 'completed').length;
      const failedScenarios = testScenarios.filter(s => s.status === 'failed').length;
      
      if (failedScenarios > 0) {
        newInsights.push({
          id: '3',
          type: 'recommendation',
          title: 'Test Scenario Optimization Needed',
          description: `${failedScenarios} test scenarios failed. Review error patterns and consider adjusting test parameters.`,
          confidence: 78,
          impact: 'medium',
          actionable: true
        });
      }
      
      // Predictive Analysis
      const recentTransactions = transactions.filter(tx => 
        new Date().getTime() - tx.timestamp.getTime() < 60 * 60 * 1000
      ).length;
      
      if (recentTransactions > 10) {
        newInsights.push({
          id: '4',
          type: 'prediction',
          title: 'High Activity Period Detected',
          description: 'Based on current transaction patterns, expect increased network load in the next hour. Consider adjusting test timing.',
          confidence: 67,
          impact: 'low',
          actionable: false
        });
      }
      
      // Performance Optimization
      newInsights.push({
        id: '5',
        type: 'optimization',
        title: 'Automated Testing Recommendation',
        description: 'Your manual testing patterns suggest implementing automated test suites could improve efficiency by 40%.',
        confidence: 88,
        impact: 'high',
        actionable: true
      });
      
      // Security Insight
      newInsights.push({
        id: '6',
        type: 'recommendation',
        title: 'Security Best Practices',
        description: 'Consider implementing multi-signature wallets for high-value test scenarios to simulate production security.',
        confidence: 95,
        impact: 'medium',
        actionable: true
      });
      
      setInsights(newInsights);
      setIsAnalyzing(false);
    }, 2000);
  };

  useEffect(() => {
    generateInsights();
  }, [transactions.length, wallets.length, testScenarios.length]);

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'optimization': return <Zap className="h-5 w-5 text-yellow-400" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-red-400" />;
      case 'recommendation': return <Lightbulb className="h-5 w-5 text-blue-400" />;
      case 'prediction': return <TrendingUp className="h-5 w-5 text-purple-400" />;
      default: return <Brain className="h-5 w-5 text-green-400" />;
    }
  };

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'optimization': return 'border-yellow-500/30 bg-yellow-500/10';
      case 'warning': return 'border-red-500/30 bg-red-500/10';
      case 'recommendation': return 'border-blue-500/30 bg-blue-500/10';
      case 'prediction': return 'border-purple-500/30 bg-purple-500/10';
      default: return 'border-green-500/30 bg-green-500/10';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-400 bg-red-400/20';
      case 'medium': return 'text-yellow-400 bg-yellow-400/20';
      case 'low': return 'text-green-400 bg-green-400/20';
      default: return 'text-slate-400 bg-slate-400/20';
    }
  };

  return (
    <div className="space-y-8">
      {/* AI Insights Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-600 bg-clip-text text-transparent mb-2">
          AI-Powered Insights
        </h1>
        <p className="text-slate-400">Intelligent analysis and recommendations for your Bitcoin testing workflow</p>
      </div>

      {/* AI Status */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">AI Analysis Engine</h3>
              <p className="text-sm text-slate-400">
                {isAnalyzing ? 'Analyzing patterns...' : `Generated ${insights.length} insights`}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-sm font-medium text-white">Confidence Score</div>
              <div className="text-lg font-bold text-green-400">
                {insights.length > 0 ? Math.round(insights.reduce((sum, i) => sum + i.confidence, 0) / insights.length) : 0}%
              </div>
            </div>
            <button
              onClick={generateInsights}
              disabled={isAnalyzing}
              className="bg-purple-600 hover:bg-purple-700 disabled:bg-slate-600 px-4 py-2 rounded-lg transition-all duration-200 flex items-center space-x-2 font-medium"
            >
              <Cpu className={`h-4 w-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isAnalyzing ? 'Analyzing...' : 'Refresh Analysis'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Optimization Score</p>
              <p className="text-2xl font-bold text-yellow-400">87%</p>
              <p className="text-xs text-green-400 mt-1">+5% this week</p>
            </div>
            <Target className="h-8 w-8 text-yellow-400" />
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Efficiency Rating</p>
              <p className="text-2xl font-bold text-green-400">92%</p>
              <p className="text-xs text-green-400 mt-1">Excellent</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Risk Level</p>
              <p className="text-2xl font-bold text-green-400">Low</p>
              <p className="text-xs text-slate-400 mt-1">2 warnings</p>
            </div>
            <Activity className="h-8 w-8 text-green-400" />
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Predictions</p>
              <p className="text-2xl font-bold text-purple-400">{insights.filter(i => i.type === 'prediction').length}</p>
              <p className="text-xs text-purple-400 mt-1">Active forecasts</p>
            </div>
            <BarChart3 className="h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>

      {/* AI Insights Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {insights.map((insight) => (
          <div
            key={insight.id}
            className={`rounded-xl border p-6 shadow-xl backdrop-blur-sm ${getInsightColor(insight.type)}`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                {getInsightIcon(insight.type)}
                <div>
                  <h3 className="text-lg font-semibold text-white">{insight.title}</h3>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className={`px-2 py-1 text-xs rounded-full font-medium capitalize ${getImpactColor(insight.impact)}`}>
                      {insight.impact} Impact
                    </span>
                    <span className="text-xs text-slate-400">
                      {insight.confidence}% confidence
                    </span>
                  </div>
                </div>
              </div>
              {insight.actionable && (
                <button className="bg-slate-600 hover:bg-slate-700 px-3 py-1 rounded-lg text-xs font-medium transition-colors">
                  Take Action
                </button>
              )}
            </div>
            
            <p className="text-slate-300 text-sm leading-relaxed mb-4">
              {insight.description}
            </p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-full bg-slate-700/50 rounded-full h-1.5 w-24">
                  <div 
                    className="bg-gradient-to-r from-purple-500 to-blue-600 h-1.5 rounded-full transition-all duration-500"
                    style={{ width: `${insight.confidence}%` }}
                  ></div>
                </div>
                <span className="text-xs text-slate-400">Confidence</span>
              </div>
              <span className="text-xs text-slate-500 capitalize">
                {insight.type}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* AI Recommendations Summary */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-white">Smart Recommendations</h3>
            <p className="text-sm text-slate-400">AI-generated action items to optimize your testing workflow</p>
          </div>
          <Lightbulb className="h-5 w-5 text-blue-400" />
        </div>
        
        <div className="space-y-4">
          <div className="flex items-start space-x-4 p-4 bg-slate-700/30 rounded-lg">
            <div className="w-2 h-2 bg-green-400 rounded-full mt-2"></div>
            <div className="flex-1">
              <h4 className="font-medium text-white mb-1">Implement Automated Test Scheduling</h4>
              <p className="text-sm text-slate-400">
                Based on your usage patterns, scheduling tests during off-peak hours could improve performance by 25%.
              </p>
            </div>
            <button className="bg-green-600 hover:bg-green-700 px-3 py-1 rounded text-xs font-medium">
              Implement
            </button>
          </div>
          
          <div className="flex items-start space-x-4 p-4 bg-slate-700/30 rounded-lg">
            <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2"></div>
            <div className="flex-1">
              <h4 className="font-medium text-white mb-1">Optimize Fee Strategy</h4>
              <p className="text-sm text-slate-400">
                Dynamic fee adjustment based on mempool conditions could reduce failed transactions by 15%.
              </p>
            </div>
            <button className="bg-yellow-600 hover:bg-yellow-700 px-3 py-1 rounded text-xs font-medium">
              Configure
            </button>
          </div>
          
          <div className="flex items-start space-x-4 p-4 bg-slate-700/30 rounded-lg">
            <div className="w-2 h-2 bg-blue-400 rounded-full mt-2"></div>
            <div className="flex-1">
              <h4 className="font-medium text-white mb-1">Enhanced Monitoring Setup</h4>
              <p className="text-sm text-slate-400">
                Adding real-time alerts for transaction failures could improve debugging efficiency by 40%.
              </p>
            </div>
            <button className="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-xs font-medium">
              Setup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};