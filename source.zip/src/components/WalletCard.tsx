import React, { useState } from 'react';
import { Wallet, Copy, Send, QrCode, MoreVertical } from 'lucide-react';
import { MidlWalletInfo } from '../services/MidlService';

interface WalletCardProps {
  wallet: MidlWalletInfo;
  onFund: (address: string) => void;
  onSend: (fromAddress: string) => void;
  onCopyAddress: (address: string) => void;
}

export const WalletCard: React.FC<WalletCardProps> = ({
  wallet,
  onFund,
  onSend,
  onCopyAddress
}) => {
  const [showMenu, setShowMenu] = useState(false);

  const formatAddress = (address: string) => {
    return `${address.slice(0, 8)}...${address.slice(-8)}`;
  };

  const getBalanceColor = (balance: number) => {
    if (balance === 0) return 'text-slate-400';
    if (balance < 1) return 'text-yellow-400';
    return 'text-green-400';
  };

  const getWalletTypeColor = (type: string) => {
    switch (type) {
      case 'xverse': return 'bg-purple-500/20 text-purple-400';
      case 'regtest': return 'bg-orange-500/20 text-orange-400';
      default: return 'bg-blue-500/20 text-blue-400';
    }
  };
  return (
    <div className="bg-slate-700 p-5 rounded-lg hover:bg-slate-600/50 transition-all duration-200 group">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${getWalletTypeColor(wallet.type)}`}>
            <Wallet className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <p className="font-semibold text-white">{wallet.label}</p>
              <span className={`px-2 py-1 text-xs rounded-full ${getWalletTypeColor(wallet.type)} font-medium`}>
                {wallet.type}
              </span>
            </div>
            <button
              onClick={() => onCopyAddress(wallet.address)}
              className="text-sm text-slate-400 font-mono hover:text-orange-400 transition-colors flex items-center space-x-1"
            >
              <span>{formatAddress(wallet.address)}</span>
              <Copy className="h-3 w-3" />
            </button>
          </div>
        </div>
        
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-1 rounded hover:bg-slate-600 transition-colors"
          >
            <MoreVertical className="h-4 w-4 text-slate-400" />
          </button>
          
          {showMenu && (
            <div className="absolute right-0 top-8 bg-slate-800 border border-slate-600 rounded-lg shadow-xl z-10 min-w-[120px]">
              <button
                onClick={() => {
                  onCopyAddress(wallet.address);
                  setShowMenu(false);
                }}
                className="w-full px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 flex items-center space-x-2"
              >
                <Copy className="h-3 w-3" />
                <span>Copy Address</span>
              </button>
              <button
                onClick={() => {
                  setShowMenu(false);
                }}
                className="w-full px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 flex items-center space-x-2"
              >
                <QrCode className="h-3 w-3" />
                <span>Show QR</span>
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-xs text-slate-400 uppercase tracking-wide">Balance</p>
          <p className={`text-xl font-bold ${getBalanceColor(wallet.balance)}`}>
            {wallet.balance.toFixed(8)} BTC
          </p>
          <p className="text-xs text-slate-500">
            ≈ ${(wallet.balance * 43250).toLocaleString()} USD
          </p>
        </div>
      </div>

      <div className="flex space-x-2">
        {wallet.type === 'regtest' && (
          <button
            onClick={() => onFund(wallet.address)}
            className="flex-1 bg-green-600 hover:bg-green-700 px-3 py-2 rounded-lg text-sm font-medium transition-colors"
          >
            Fund
          </button>
        )}
        <button
          onClick={() => onSend(wallet.address)}
          disabled={wallet.balance === 0}
          className={`${wallet.type === 'regtest' ? 'flex-1' : 'w-full'} bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-1`}
        >
          <Send className="h-3 w-3" />
          <span>Send</span>
        </button>
      </div>
      
      {wallet.derivationPath && (
        <div className="mt-3 pt-3 border-t border-slate-600">
          <p className="text-xs text-slate-500 font-mono">{wallet.derivationPath}</p>
        </div>
      )}
    </div>
  );
};