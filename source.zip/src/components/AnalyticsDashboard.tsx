import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Clock,
  Target,
  Zap,
  Activity
} from 'lucide-react';
import { Transaction } from '../types';
import { MidlWalletInfo } from '../services/MidlService';
import { NodeStatus } from '../types';

interface AnalyticsDashboardProps {
  transactions: Transaction[];
  wallets: MidlWalletInfo[];
  nodeStatus: NodeStatus;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  transactions,
  wallets,
  nodeStatus
}) => {
  // Calculate analytics
  const totalTransactions = transactions.length;
  const successfulTransactions = transactions.filter(tx => tx.status === 'confirmed').length;
  const pendingTransactions = transactions.filter(tx => tx.status === 'pending').length;
  const failedTransactions = transactions.filter(tx => tx.status === 'failed').length;
  
  const successRate = totalTransactions > 0 ? (successfulTransactions / totalTransactions) * 100 : 0;
  const totalVolume = transactions.reduce((sum, tx) => sum + tx.amount, 0);
  const averageTransactionSize = totalTransactions > 0 ? totalVolume / totalTransactions : 0;
  
  // Transaction frequency analysis
  const last24Hours = transactions.filter(tx => 
    new Date().getTime() - tx.timestamp.getTime() < 24 * 60 * 60 * 1000
  ).length;
  
  const transactionsByHour = Array.from({ length: 24 }, (_, i) => {
    const hour = new Date().getHours() - i;
    const hourTransactions = transactions.filter(tx => {
      const txHour = tx.timestamp.getHours();
      return txHour === (hour >= 0 ? hour : 24 + hour);
    }).length;
    return { hour: hour >= 0 ? hour : 24 + hour, count: hourTransactions };
  }).reverse();

  const maxHourlyTransactions = Math.max(...transactionsByHour.map(h => h.count), 1);

  return (
    <div className="space-y-8">
      {/* Analytics Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-400 to-orange-600 bg-clip-text text-transparent mb-2">
          Transaction Analytics
        </h1>
        <p className="text-slate-400">Comprehensive insights into your Bitcoin testing activity</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Total Transactions</p>
              <p className="text-2xl font-bold text-white">{totalTransactions}</p>
              <p className="text-xs text-green-400 mt-1">+{last24Hours} in 24h</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Activity className="h-6 w-6 text-blue-400" />
            </div>
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Success Rate</p>
              <p className="text-2xl font-bold text-white">{successRate.toFixed(1)}%</p>
              <p className="text-xs text-green-400 mt-1">
                {successfulTransactions}/{totalTransactions} confirmed
              </p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <Target className="h-6 w-6 text-green-400" />
            </div>
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Total Volume</p>
              <p className="text-2xl font-bold text-white">{totalVolume.toFixed(4)} BTC</p>
              <p className="text-xs text-slate-400 mt-1">
                Avg: {averageTransactionSize.toFixed(6)} BTC
              </p>
            </div>
            <div className="p-3 bg-orange-500/20 rounded-lg">
              <DollarSign className="h-6 w-6 text-orange-400" />
            </div>
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Pending</p>
              <p className="text-2xl font-bold text-white">{pendingTransactions}</p>
              <p className="text-xs text-yellow-400 mt-1">
                {failedTransactions} failed
              </p>
            </div>
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <Clock className="h-6 w-6 text-yellow-400" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Transaction Frequency Chart */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Transaction Frequency</h3>
              <p className="text-sm text-slate-400">Transactions per hour (last 24h)</p>
            </div>
            <BarChart3 className="h-5 w-5 text-orange-400" />
          </div>
          
          <div className="space-y-3">
            {transactionsByHour.slice(-12).map((hourData, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-8 text-xs text-slate-400 font-mono">
                  {hourData.hour.toString().padStart(2, '0')}:00
                </div>
                <div className="flex-1 bg-slate-700/50 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-orange-500 to-orange-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${(hourData.count / maxHourlyTransactions) * 100}%` }}
                  ></div>
                </div>
                <div className="w-8 text-xs text-slate-300 text-right">
                  {hourData.count}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Wallet Distribution */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Wallet Distribution</h3>
              <p className="text-sm text-slate-400">Balance distribution across wallets</p>
            </div>
            <TrendingUp className="h-5 w-5 text-green-400" />
          </div>
          
          <div className="space-y-4">
            {wallets.map((wallet, index) => {
              const totalBalance = wallets.reduce((sum, w) => sum + w.balance, 0);
              const percentage = totalBalance > 0 ? (wallet.balance / totalBalance) * 100 : 0;
              
              return (
                <div key={wallet.address} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${
                        wallet.type === 'xverse' ? 'bg-purple-400' : 'bg-orange-400'
                      }`}></div>
                      <span className="text-sm font-medium text-white">{wallet.label}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-white">
                        {wallet.balance.toFixed(4)} BTC
                      </div>
                      <div className="text-xs text-slate-400">
                        {percentage.toFixed(1)}%
                      </div>
                    </div>
                  </div>
                  <div className="w-full bg-slate-700/50 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-500 ${
                        wallet.type === 'xverse' 
                          ? 'bg-gradient-to-r from-purple-500 to-purple-600' 
                          : 'bg-gradient-to-r from-orange-500 to-orange-600'
                      }`}
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-white">Performance Metrics</h3>
            <p className="text-sm text-slate-400">System and network performance indicators</p>
          </div>
          <Zap className="h-5 w-5 text-yellow-400" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-slate-700/30 rounded-lg">
            <div className="text-2xl font-bold text-green-400 mb-1">
              {nodeStatus.blockHeight}
            </div>
            <div className="text-sm text-slate-400">Current Block Height</div>
          </div>
          
          <div className="text-center p-4 bg-slate-700/30 rounded-lg">
            <div className="text-2xl font-bold text-blue-400 mb-1">
              {nodeStatus.connections}
            </div>
            <div className="text-sm text-slate-400">Network Connections</div>
          </div>
          
          <div className="text-center p-4 bg-slate-700/30 rounded-lg">
            <div className="text-2xl font-bold text-purple-400 mb-1">
              {nodeStatus.mempool}
            </div>
            <div className="text-sm text-slate-400">Mempool Transactions</div>
          </div>
        </div>
      </div>

      {/* Recent Activity Timeline */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700/50 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-white">Recent Activity</h3>
            <p className="text-sm text-slate-400">Latest transaction activity timeline</p>
          </div>
        </div>
        
        <div className="space-y-4 max-h-64 overflow-y-auto">
          {transactions.slice(0, 10).map((tx, index) => (
            <div key={tx.id} className="flex items-center space-x-4 p-3 bg-slate-700/30 rounded-lg">
              <div className={`w-2 h-2 rounded-full ${
                tx.status === 'confirmed' ? 'bg-green-400' :
                tx.status === 'pending' ? 'bg-yellow-400' : 'bg-red-400'
              }`}></div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-white capitalize">
                    {tx.type} Transaction
                  </span>
                  <span className="text-sm text-slate-400">
                    {tx.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  {tx.amount.toFixed(8)} BTC • {tx.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};