import React from 'react';
import { Play, CheckCircle, AlertCircle, Clock, RotateCcw } from 'lucide-react';
import { TestScenario } from '../types';

interface TestScenarioCardProps {
  scenario: TestScenario;
  onRun: (scenarioId: string) => void;
  onReset: (scenarioId: string) => void;
}

export const TestScenarioCard: React.FC<TestScenarioCardProps> = ({
  scenario,
  onRun,
  onReset
}) => {
  const getStatusIcon = () => {
    switch (scenario.status) {
      case 'completed': return <CheckCircle className="h-5 w-5 text-green-400" />;
      case 'failed': return <AlertCircle className="h-5 w-5 text-red-400" />;
      case 'running': return <Clock className="h-5 w-5 text-yellow-400 animate-spin" />;
      default: return <Play className="h-5 w-5 text-slate-400" />;
    }
  };

  const getStatusColor = () => {
    switch (scenario.status) {
      case 'completed': return 'bg-green-500/10 text-green-400 border-green-500/20';
      case 'failed': return 'bg-red-500/10 text-red-400 border-red-500/20';
      case 'running': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
      default: return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  const successRate = scenario.results ? 
    (scenario.results.filter(r => r.success).length / scenario.results.length) * 100 : 0;

  return (
    <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 hover:border-slate-600 transition-all duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-white mb-2">{scenario.name}</h3>
          <p className="text-sm text-slate-400 mb-3">{scenario.description}</p>
          
          <div className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full border text-sm ${getStatusColor()}`}>
            {getStatusIcon()}
            <span className="capitalize">{scenario.status}</span>
          </div>
        </div>
      </div>

      <div className="mb-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-slate-400">Steps: {scenario.steps.length}</span>
          {scenario.results && (
            <span className="text-slate-400">Success Rate: {successRate.toFixed(0)}%</span>
          )}
        </div>
        
        {scenario.results && (
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div 
              className="bg-green-400 h-2 rounded-full transition-all duration-500"
              style={{ width: `${successRate}%` }}
            ></div>
          </div>
        )}
      </div>

      <div className="flex space-x-2">
        <button
          onClick={() => onRun(scenario.id)}
          disabled={scenario.status === 'running'}
          className="flex-1 bg-orange-600 hover:bg-orange-700 disabled:bg-slate-600 disabled:cursor-not-allowed px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-2"
        >
          <Play className="h-4 w-4" />
          <span>{scenario.status === 'running' ? 'Running...' : 'Run Test'}</span>
        </button>
        
        {scenario.status !== 'idle' && (
          <button
            onClick={() => onReset(scenario.id)}
            className="px-4 py-2 bg-slate-600 hover:bg-slate-700 rounded-lg text-sm font-medium transition-colors"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
};